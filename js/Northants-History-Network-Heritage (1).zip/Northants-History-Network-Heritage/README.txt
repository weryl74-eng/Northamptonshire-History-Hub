NORTHANTS HISTORY NETWORK — HERITAGE HOMEPAGE

This package contains a coded website based closely on the approved green-and-cream mock-up.

FILES
• index.html
• css/style.css
• images/nhn-logo-green.jpg

TO INSTALL
1. Unzip the folder.
2. Copy index.html, the css folder and the images folder into your existing Northamptonshire-History-Hub project.
3. Choose Replace when Windows asks about existing files.
4. Open index.html in Visual Studio Code.
5. Refresh the browser using Ctrl + F5.

NOTES
• The layout, pale cream background, green-and-gold palette, round logo, sections and footer are all included.
• The photographs are temporary online images. We can replace them with real Northamptonshire images.
• The buttons are currently demonstration links (#). We will connect them to real pages, forms and websites next.
